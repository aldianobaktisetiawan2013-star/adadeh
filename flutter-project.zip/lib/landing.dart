import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'api_config.dart';
import 'login_page.dart';
import 'buy_akses_sheet.dart';

// ─── Palette: Dark Blue / Cyan ──────────────────────────────
class _C {
  // Background - dark navy
  static const bg         = Color(0xFF06131A);
  static const surface    = Color(0xFF0C1D26);
  static const card       = Color(0xFF122833);
  static const logoBg     = Color(0xFF16313D);
  static const border     = Color(0xFF2B5D6A);

  // Accent Cyan
  static const cyan       = Color(0xFF7CF7ED);
  static const cyanDark   = Color(0xFF39C7D9);
  static const cyanDim    = Color(0xFF67DDE2);
  static const cyanBorder = Color(0xFF5EEFFF);

  // Text
  static const text       = Color(0xFFEFFFFF);
  static const textSub    = Color(0xFFA8D7DF);
  static const textDim    = Color(0xFF6F95A0);

  // Social
  static const socialCyan = Color(0xFF5EEFFF);
  static const socialGrey = Color(0xFF1F3440);
  static const socialRed  = Color(0xFF39C7D9); // opsional, biar konsisten biru
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _floatCtrl;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOutCubic);
    
    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fadeCtrl.forward();
    });
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _floatCtrl.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $uri');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.2,
            colors: [
              _C.surface,
              _C.bg,
              Color(0xFF0A0000),
            ],
            stops: [0, 0.5, 1],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 24),
                  _buildLogoBox(),
                  const SizedBox(height: 32),
                  _buildBigTitle(),
                  const SizedBox(height: 28),
                  _buildDescCard(),
                  const SizedBox(height: 20),
                  _buildLoginButton(),
                  const SizedBox(height: 14),
                  _buildBuyAksesButton(),
                  const SizedBox(height: 14),
                  _buildContactSupportButton(),
                  const SizedBox(height: 28),
                  _buildSocialSection(),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLogoBox() {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 24),
    child: AnimatedBuilder(
      animation: _floatCtrl,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, 5 * _floatCtrl.value),
          child: Container(
            width: double.infinity,
            height: 210,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  _C.logoBg.withOpacity(0.9),
                  _C.card.withOpacity(0.8),
                ],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: _C.cyan.withOpacity(0.2),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: _C.cyan.withOpacity(0.1),
                  blurRadius: 20,
                  spreadRadius: 2,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Gambar full bingkai
                ClipRRect(
                  borderRadius: BorderRadius.circular(28),
                  child: Image.asset(
                    'assets/images/login.png',
                    width: double.infinity,
                    height: double.infinity,
                    fit: BoxFit.cover,
                  ),
                ),
                // Overlay gelap agar teks lebih terbaca
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [
                        Colors.black.withOpacity(0.7),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}

  Widget _buildBigTitle() {
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [
              Color(0xFFFFFFFF), // putih di kiri
              Color(0xFFFF4040), // cyan di tengah-kanan
              Color(0xFFFFFFFF), // putih hint di ujung
            ],
            stops: [0.0, 0.6, 1.0],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: const Text(
            'MASTRAX PROJECT',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 44,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
              letterSpacing: 4,
              height: 1.0,
            ),
          ),
        ),
        const SizedBox(height: 12),
        Container(
          width: 140,
          height: 2,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: const LinearGradient(
              colors: [Colors.transparent, _C.cyan, _C.cyanDark, Colors.transparent],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_C.cyan.withOpacity(0.1), _C.cyanDark.withOpacity(0.05)],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.cyan.withOpacity(0.2)),
          ),
          child: const Text(
            'P R E M I U M   •   T E R U P D A T E   •   C A N G G I H',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _C.cyan,
              fontSize: 11,
              letterSpacing: 2,
              fontWeight: FontWeight.w600,
              fontFamily: 'Orbitron',
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDescCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              _C.card.withOpacity(0.7),
              _C.card.withOpacity(0.5),
            ],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: _C.cyan.withOpacity(0.2),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: _C.cyan.withOpacity(0.08),
              blurRadius: 15,
              spreadRadius: 1,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_C.cyanDim.withOpacity(0.6), _C.cyan.withOpacity(0.3)],
                ),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: _C.cyan.withOpacity(0.5), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: _C.cyan.withOpacity(0.3),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: const Center(
                child: Icon(
                  Icons.shield_outlined,
                  color: _C.cyan,
                  size: 30,
                ),
              ),
            ),
            const SizedBox(height: 20),
            ShaderMask(
              shaderCallback: (bounds) => const LinearGradient(
                colors: [Color(0xFFFF4040), Color(0xFFE50914)],
              ).createShader(bounds),
              child: const Text(
                'X-NULL BUG',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Aplikasi dengan design elegant dan fitur terbaru.\nPengembangan langsung oleh TEAM MASTRAX PROJECT.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _C.textSub,
                fontSize: 13,
                height: 1.6,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoginButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              _C.cyan.withOpacity(0.15),
              _C.cyanDark.withOpacity(0.1),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.cyan, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: _C.cyan.withOpacity(0.2),
              blurRadius: 10,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => LoginPage()),
            ),
            borderRadius: BorderRadius.circular(16),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.rocket_launch_rounded, color: _C.cyan, size: 20),
                  SizedBox(width: 12),
                  Text(
                    'LOGIN TO X-NULL',
                    style: TextStyle(
                      color: _C.cyan,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContactSupportButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          color: _C.card.withOpacity(0.5),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.border, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 8,
              spreadRadius: 0,
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => _openUrl('https://t.me/@ALLEGANTENGG'),
            borderRadius: BorderRadius.circular(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.headset_mic_rounded, color: _C.textSub, size: 20),
                const SizedBox(width: 12),
                Text(
                  'CONTACT SUPPORT',
                  style: TextStyle(
                    color: _C.textSub,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSocialSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              _C.card.withOpacity(0.6),
              _C.card.withOpacity(0.4),
            ],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: _C.border, width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 12,
              spreadRadius: 2,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: _C.cyan.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _C.cyan.withOpacity(0.2)),
              ),
              child: Text(
                'HUBUNGI KAMI',
                style: TextStyle(
                  color: _C.cyan,
                  fontSize: 11,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 24),
            Row(
  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
  children: [
    _buildSocialItem(
      icon: FontAwesomeIcons.telegram,
      bgColor: Color(0xFFFF4040),
      label: 'Telegram',
      onTap: () => _openUrl('https://t.me/@ALLEGANTENGG'),
    ),
    _buildSocialItem(
      icon: FontAwesomeIcons.tiktok,
      bgColor: Color(0xFF5C2020),
      label: 'TikTok',
      onTap: () => _openUrl('https://tiktok.com/@lenstoree'),
    ),
    _buildSocialItem(
      icon: FontAwesomeIcons.instagram,
      bgColor: Color(0xFFE50914),
      label: 'Instagram',
      onTap: () => _openUrl('https://www.instagram.com/lentzzzstore?igsh=eW1sZXhpOWZsOG1t'),
    ),
  ],
),
          ],
        ),
      ),
    );
  }

  Widget _buildSocialItem({
  required IconData icon,
  required Color bgColor,
  required String label,
  required VoidCallback onTap,
}) {
  return GestureDetector(
    onTap: onTap,
    child: Column(
      children: [
        Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: bgColor.withOpacity(0.15),
            border: Border.all(color: bgColor.withOpacity(0.8), width: 2),
            boxShadow: [
              BoxShadow(
                color: bgColor.withOpacity(0.35),
                blurRadius: 14,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Center(
            child: FaIcon(icon, color: bgColor, size: 26),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          label,
          style: TextStyle(
            color: _C.textSub,
            fontSize: 11,
            fontWeight: FontWeight.w500,
            letterSpacing: 1,
          ),
        ),
      ],
    ),
  );
 }

  void _showBuyAksesSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _BuyAksesSheet(
        onBuy: (url) async {
          Navigator.pop(context);
          await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
        },
      ),
    );
  }

  Widget _buildBuyAksesButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFE50914), Color(0xFF8B0000)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFE50914).withOpacity(0.4),
              blurRadius: 14,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: _showBuyAksesSheet,
            borderRadius: BorderRadius.circular(16),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.shopping_cart_rounded, color: Colors.white, size: 20),
                SizedBox(width: 12),
                Text(
                  'BUY AKSES',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
// ─── Buy Akses Bottom Sheet ──────────────────
class _BuyAksesSheet extends StatefulWidget {
  final Future<void> Function(String url) onBuy;
  const _BuyAksesSheet({required this.onBuy});

  @override
  State<_BuyAksesSheet> createState() => _BuyAksesSheetState();
}

class _BuyAksesSheetState extends State<_BuyAksesSheet> {
  int _selectedPackage = 0;
  String _selectedRole = 'full_up';

  final _telegramUrl = 'https://t.me/@ALLEGANTENGG';

  final Map<String, Map<String, dynamic>> _packages = {
    'full_up': {
      'label': 'FULL UP',
      'desc': 'Paket member standar',
      'color': const Color(0xFFB06060),
      'plans': [
        {'name': 'Trial Sehari',  'price': 'Rp 2.000',  'icon': Icons.access_time_rounded},
        {'name': 'Trial Sebulan', 'price': 'Rp 10.000', 'icon': Icons.calendar_month_rounded},
        {'name': 'Permanen',      'price': 'Rp 15.000', 'icon': Icons.all_inclusive_rounded},
      ],
    },
    'reseller': {
      'label': 'RESELLER',
      'desc': 'Bisa create akun Full Up',
      'color': const Color(0xFF22C55E),
      'plans': [
        {'name': 'Permanen', 'price': 'Rp 20.000', 'icon': Icons.all_inclusive_rounded},
      ],
    },
    'vip': {
      'label': 'VIP',
      'desc': 'Bisa create sampai Reseller',
      'color': const Color(0xFFE50914),
      'plans': [
        {'name': 'Permanen', 'price': 'Rp 25.000', 'icon': Icons.all_inclusive_rounded},
      ],
    },
    'owner': {
      'label': 'OWNER',
      'desc': 'Bisa create sampai VIP + Sender Global',
      'color': const Color(0xFFF59E0B),
      'plans': [
        {'name': 'Permanen', 'price': 'Rp 40.000', 'icon': Icons.all_inclusive_rounded},
      ],
    },
    'high_owner': {
      'label': 'HIGH OWNER',
      'desc': 'Bisa create sampai Owner',
      'color': const Color(0xFFFF6600),
      'plans': [
        {'name': 'Permanen', 'price': 'Rp 50.000', 'icon': Icons.all_inclusive_rounded},
      ],
    },
    'founder': {
      'label': 'FOUNDER',
      'desc': 'Bisa create sampai High Owner',
      'color': const Color(0xFFFF4500),
      'plans': [
        {'name': 'Permanen', 'price': 'Rp 60.000', 'icon': Icons.all_inclusive_rounded},
      ],
    },
  };

  @override
  Widget build(BuildContext context) {
    final pkg = _packages[_selectedRole]!;
    final plans = pkg['plans'] as List;
    final color = pkg['color'] as Color;

    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      decoration: const BoxDecoration(
        color: Color(0xFF150000),
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        border: Border(top: BorderSide(color: Color(0xFF3B0A0A))),
      ),
      child: Column(
        children: [
          // Handle
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40, height: 4,
            decoration: BoxDecoration(
              color: const Color(0xFF3B0A0A),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          // Header
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE50914).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFE50914).withOpacity(0.4)),
                  ),
                  child: const Icon(Icons.shopping_bag_rounded, color: Color(0xFFE50914), size: 22),
                ),
                const SizedBox(width: 14),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('BUY AKSES',
                      style: TextStyle(
                        color: Color(0xFFF5E0E0),
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                    Text('Pilih paket yang sesuai',
                      style: TextStyle(color: Color(0xFFB06060), fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // Role Selector
          SizedBox(
            height: 40,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: _packages.entries.map((e) {
                final isSelected = _selectedRole == e.key;
                final c = e.value['color'] as Color;
                return GestureDetector(
                  onTap: () => setState(() {
                    _selectedRole = e.key;
                    _selectedPackage = 0;
                  }),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: isSelected ? c.withOpacity(0.2) : const Color(0xFF1C0000),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: isSelected ? c : const Color(0xFF3B0A0A),
                        width: isSelected ? 1.5 : 1,
                      ),
                    ),
                    child: Text(
                      e.value['label'] as String,
                      style: TextStyle(
                        color: isSelected ? c : const Color(0xFF5C2020),
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 16),
          // Package Card
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  // Info Card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [color.withOpacity(0.15), color.withOpacity(0.05)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: color.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(Icons.workspace_premium_rounded, color: color, size: 24),
                        ),
                        const SizedBox(width: 14),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              pkg['label'] as String,
                              style: TextStyle(
                                color: color,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                            Text(
                              pkg['desc'] as String,
                              style: const TextStyle(color: Color(0xFFB06060), fontSize: 12),
                            ),
                          ],
                        ),
                        if (_selectedRole == 'full_up') ...[
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF59E0B).withOpacity(0.15),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: const Color(0xFFF59E0B).withOpacity(0.4)),
                            ),
                            child: const Text('RECOMMENDED',
                              style: TextStyle(
                                color: Color(0xFFF59E0B),
                                fontSize: 9,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  // Plans
                  ...plans.asMap().entries.map((entry) {
                    final i = entry.key;
                    final plan = entry.value as Map;
                    final isSelected = _selectedPackage == i;
                    return GestureDetector(
                      onTap: () => setState(() => _selectedPackage = i),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? color.withOpacity(0.1)
                              : const Color(0xFF1C0000),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isSelected ? color : const Color(0xFF3B0A0A),
                            width: isSelected ? 1.5 : 1,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 28, height: 28,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: isSelected
                                    ? color.withOpacity(0.2)
                                    : const Color(0xFF0A0000),
                                border: Border.all(
                                  color: isSelected ? color : const Color(0xFF3B0A0A),
                                  width: 2,
                                ),
                              ),
                              child: isSelected
                                  ? Icon(Icons.check_rounded, color: color, size: 16)
                                  : null,
                            ),
                            const SizedBox(width: 14),
                            Icon(plan['icon'] as IconData, color: isSelected ? color : const Color(0xFF5C2020), size: 20),
                            const SizedBox(width: 10),
                            Text(
                              plan['name'] as String,
                              style: TextStyle(
                                color: isSelected ? const Color(0xFFF5E0E0) : const Color(0xFFB06060),
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                            const Spacer(),
                            Text(
                              plan['price'] as String,
                              style: TextStyle(
                                color: isSelected ? color : const Color(0xFF5C2020),
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
          // Buy Button
          Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, MediaQuery.of(context).padding.bottom + 16),
            child: GestureDetector(
              onTap: () {
                final plan = plans[_selectedPackage];
                final msg = 'Halo, saya mau beli akses ${pkg['label']} - ${plan['name']} (${plan['price']})';
                final url = 'https://t.me/@ALLEGANTENGG?text=${Uri.encodeComponent(msg)}';
                widget.onBuy(url);
              },
              child: Container(
                width: double.infinity,
                height: 56,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color, color.withOpacity(0.7)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: color.withOpacity(0.4),
                      blurRadius: 14,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.shopping_cart_checkout_rounded, color: Colors.white, size: 20),
                    const SizedBox(width: 10),
                    Text(
                      'CONTACT & BUY AKSES',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
  // ── BUY AKSES ─────────────────────────────────
}
