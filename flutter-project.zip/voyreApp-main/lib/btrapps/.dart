import 'dart:convert';
import 'package:http/http.dart' as http;

class Api {
  static String _baseUrl = ''; 
  
  static String get api {
    if (_baseUrl.isEmpty) {
      return 'http://104.248.145.75:4000';
    }
    return _baseUrl;
  }
  
  static Future<void> loadGh() async {
    try {
      final url = 'https://raw.githubusercontent.com/Rizik23/key/main/x.json';
      final response = await http.get(
        Uri.parse(url),
        headers: {
          // Token otorisasi dihapus biar aman dan lolos sensor GitHub
          'Accept': 'application/vnd.github.v3+json'
        },
      );     
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['x'] != null) {
          _baseUrl = data['x'];
        }
      }
    } catch (e) {
      print('$e');
    }
  }
}
